import { useRouter } from "next/router";
import { useState } from "react";
import handler from "./api/hello";

interface UserCred {
  name: string;
  pass: string;
}

export default function Index2() {
  const router = useRouter();

  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");

  // Lista de usuarios de ejemplo. Reemplaza por tu fuente real (API, DB, etc.)
  const usuarios: UserCred[] = [
    { name: "admin", pass: "1234" },
    { name: "juan", pass: "abcd" },
    { name: "santy", pass: "12345" },
  ];

  const handleClick = () => {
    console.log("Usuario:", user, "Contraseña:", pass);

    if (user === "" || pass === "") {
      alert("Debe ingresar Usuario y contraseña");
      return;
    }

    const userFound = usuarios.find((item) => item.name === user);

    if (!userFound) {
      alert("Usuario o contraseña incorrectas");
      return;
    }

    if (userFound.pass === pass) {
      router.push("/dashboard/dashboard"); // navega al dashboard
    } else {
      alert("Usuario o contraseña incorrectas");
    }
  };

  // const irDashboard = () => {
  //   router.push("/dashboard/dashboard"); // navega al dashboard
  // };

  const handleChangeUser = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUser(e.target.value);
    console.log(e.target.value);
  };

  const handleChangePass = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPass(e.target.value);
    console.log(e.target.value);
  };
  const handlerclick = () => {
    console.log("hola, front");
    const useServices = new useServices();

    const users = userClass.getUsers();

    console.log(users);

    //lamar
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-cyan-200 px-4">
      <h1 className="text-4xl font-extrabold text-gray-800 mb-8">
        Soy la página Index2
      </h1>

      {/* <button
    className="w-full max-w-xs px-6 py-3 bg-red-800 text-white font-medium rounded-lg shadow-md hover:bg-blue-700 transition"
    onClick={() => router.push("/dashboard/dashboard")}
  >
    Ir al Dashboard 🚫
  </button> */}

      <form className="w-full max-w-sm mt-8 space-y-6 bg-neutral-50 p-6 rounded-xl shadow">
        <div className="flex flex-col space-y-2">
          <label className="text-zinc-950  font-medium">Usuario</label>
          <input
            type="text"
            onChange={handleChangeUser}
            value={user}
            className="px-4 py-2 border text-zinc-950  rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex flex-col space-y-2">
          <label className="text-zinc-950  font-medium">Contraseña</label>
          <input
            type="password"
            onChange={handleChangePass}
            value={pass}
            className="px-4 py-2 border text-zinc-950 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <button
          type="button"
          onClick={handleClick}
          className="w-full px-6 py-3 bg-green-600 text-white font-medium rounded-lg shadow-md hover:bg-green-700 transition"
        >
          Ingresar
        </button>
      </form>

      <button onClick={handleClick}>obteneer users</button>

      {/* <button
    onClick={irDashboard}
    className="w-full max-w-xs mt-8 px-6 py-3 bg-red-800 text-white font-medium rounded-lg shadow-md hover:bg-amber-700 transition"
  >
    Ir a Dashboard 🚫 (No tocar)
  </button> */}
    </div>
  );
}
