// src/pages/api/users.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { userStore, UserCred } from '../../utils/UserStore';

type ErrorRes = { error: string };

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<UserCred[] | UserCred | ErrorRes>
) {
  if (req.method === 'GET') {
    return res.status(200).json(userStore.list());
  }

  if (req.method === 'POST') {
    // Next.js normalmente parsea JSON automáticamente.
    // Si en tu cliente mandas texto JSON, esta línea lo maneja.
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const { name, pass } = body as Partial<UserCred>;

    if (!name || !pass) {
      return res.status(400).json({ error: 'name and pass required' });
    }

    const created = userStore.create({ name, pass });
    if (!created) {
      return res.status(409).json({ error: 'user already exists' });
    }

    return res.status(201).json(created);
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
}
