// src/pages/api/users/[name].ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { userStore, UserCred } from '../../utils/UserStore';

type ErrorRes = { error: string };

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<UserCred | ErrorRes | null>
) {
  const name = Array.isArray(req.query.name) ? req.query.name[0] : req.query.name;
  if (!name) return res.status(400).json({ error: 'name required' });

  if (req.method === 'GET') {
    const user = userStore.findByName(name);
    if (!user) return res.status(404).json({ error: 'not found' });
    return res.status(200).json(user);
  }

  if (req.method === 'PATCH') {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const patch = body as Partial<UserCred>;
    const updated = userStore.update(name, patch);
    if (!updated) return res.status(404).json({ error: 'not found' });
    return res.status(200).json(updated);
  }

  if (req.method === 'DELETE') {
    const removed = userStore.remove(name);
    if (!removed) return res.status(404).json({ error: 'not found' });
    return res.status(204).end();
  }

  res.setHeader('Allow', ['GET', 'PATCH', 'DELETE']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
}
