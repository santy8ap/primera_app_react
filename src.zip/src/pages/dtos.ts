interface Users {
    name: string;
    age: number;
}