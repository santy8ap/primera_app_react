

class useServices {
    url:string = `http://localhost:3000/`;
    
    

    // constructor()

   async getUsers(){
       const result = await fetch(`${this.url}/api/hello`)
         return result;
    }
}