// src/pages/dashboard/dashboard.tsx
import { useRouter } from 'next/router';
import { useState } from 'react';

export default function Dashboard() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [pass, setPass] = useState('');
  const [output, setOutput] = useState<string | null>(null);

  const api = (path = '/api/users') => path;

  async function listUsers() {
    const res = await fetch(api());
    const data = await res.json();
    setOutput(JSON.stringify(data, null, 2));
    console.log('LIST response', data);
  }

  async function createUser() {
    const res = await fetch(api(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, pass }),
    });
    const data = await res.json().catch(() => null);
    setOutput(res.status === 201 ? `Creado: ${JSON.stringify(data)}` : `Error ${res.status}: ${JSON.stringify(data)}`);
    console.log('CREATE response', res.status, data);
  }

  async function getUser() {
    const res = await fetch(api(`/api/users/${encodeURIComponent(name)}`.replace('/api/users', '/api/users')));
    const data = await res.json().catch(() => null);
    setOutput(res.status === 200 ? JSON.stringify(data, null, 2) : `Error ${res.status}: ${JSON.stringify(data)}`);
    console.log('GET response', res.status, data);
  }

  async function patchUser() {
    const res = await fetch(api(`/api/users/${encodeURIComponent(name)}`.replace('/api/users', '/api/users')), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pass }),
    });
    const data = await res.json().catch(() => null);
    setOutput(res.status === 200 ? `Actualizado: ${JSON.stringify(data)}` : `Error ${res.status}: ${JSON.stringify(data)}`);
    console.log('PATCH response', res.status, data);
  }

  async function deleteUser() {
    const res = await fetch(api(`/api/users/${encodeURIComponent(name)}`.replace('/api/users', '/api/users')), {
      method: 'DELETE',
    });
    setOutput(res.status === 204 ? `Eliminado ${name}` : `Error ${res.status}`);
    console.log('DELETE response', res.status);
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-zinc-950 ">
      <h1 className="text-3xl font-bold mb-6 text-amber-50">Dashboard</h1>
      <p className="mb-4 text-amber-50">Ruta actual: {router.pathname}</p>

      <div className="w-full max-w-lg bg-white p-6 rounded-lg shadow space-y-4">
        <div className="flex gap-2">
          <input
            placeholder="nombre"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="flex-1 px-3 py-2 border rounded"
          />
          <input
            placeholder="contraseña"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            className="w-40 px-3 py-2 border rounded"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          <button onClick={listUsers} className="px-4 py-2 bg-blue-600 text-zinc-950  rounded">List</button>
          <button onClick={createUser} className="px-4 py-2 bg-green-600 text-zinc-950  rounded">Create</button>
          <button onClick={getUser} className="px-4 py-2 bg-gray-600 text-zinc-950  rounded">Get</button>
          <button onClick={patchUser} className="px-4 py-2 bg-amber-600 text-zinc-950  rounded">Patch</button>
          <button onClick={deleteUser} className="px-4 py-2 bg-red-600 text-zinc-950  rounded">Delete</button>
          <button onClick={() => router.push('/')} className="px-4 py-2   text-black rounded">Volver al Home</button>
        </div>

        <pre className="bg-black text-white p-3 rounded max-h-48 overflow-auto text-sm">{output ?? 'Resultados aquí'}</pre>
      </div>
    </div>
  );
}
