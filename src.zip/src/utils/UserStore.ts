// src/utils/UserStore.ts
export interface UserCred {
  name: string;
  pass: string;
}

class UserStore {
  private items: UserCred[] = [];

  constructor(initial: UserCred[] = []) {
    this.items = [...initial];
  }

  list(): UserCred[] {
    console.log('[GET] /users - list all users');
    return this.items.map(u => ({ ...u }));
  }

  findByName(name: string): UserCred | null {
    console.log(`[GET] /users/${name} - findByName`);
    const found = this.items.find(u => u.name === name);
    return found ? { ...found } : null;
  }

  create(user: UserCred): UserCred | null {
    console.log('[POST] /users - create', user.name);
    if (this.items.some(u => u.name === user.name)) {
      console.log('[POST] /users - duplicate', user.name);
      return null;
    }
    this.items.push({ ...user });
    return { ...user };
  }

  update(name: string, patch: Partial<UserCred>): UserCred | null {
    console.log(`[PATCH] /users/${name} - update`, patch);
    const idx = this.items.findIndex(u => u.name === name);
    if (idx === -1) return null;
    this.items[idx] = { ...this.items[idx], ...patch };
    return { ...this.items[idx] };
  }

  remove(name: string): boolean {
    console.log(`[DELETE] /users/${name} - remove`);
    const idx = this.items.findIndex(u => u.name === name);
    if (idx === -1) return false;
    this.items.splice(idx, 1);
    return true;
  }
}

export const userStore = new UserStore([
  { name: 'admin', pass: '1234' },
  { name: 'juan', pass: 'abcd' },
]);

export default UserStore;
